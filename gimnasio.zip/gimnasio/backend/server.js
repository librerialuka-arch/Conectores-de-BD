const path = require('path');
const express = require('express');
const Database = require('better-sqlite3');

const app = express();
const PORT = process.env.PORT || 3000;

const db = new Database(path.join(__dirname, 'gimnasio.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS miembros (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre         TEXT NOT NULL,
    plan_pago      TEXT NOT NULL,
    fecha_registro TEXT NOT NULL DEFAULT (date('now', 'localtime'))
  )
`);

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'frontend')));

const PLANES_VALIDOS = ['Mensual', 'Trimestral', 'Anual'];

app.get('/api/miembros', (req, res) => {
  const miembros = db.prepare('SELECT * FROM miembros ORDER BY id DESC').all();
  res.json(miembros);
});

app.post('/api/miembros', (req, res) => {
  const { nombre, plan_pago } = req.body ?? {};
  const nombreLimpio = String(nombre ?? '').trim();

  if (!nombreLimpio) {
    return res.status(400).json({ error: 'Escribe el nombre del miembro.' });
  }
  if (!PLANES_VALIDOS.includes(plan_pago)) {
    return res.status(400).json({ error: 'Elige un plan de pago de la lista.' });
  }

  const resultado = db
    .prepare('INSERT INTO miembros (nombre, plan_pago) VALUES (?, ?)')
    .run(nombreLimpio, plan_pago);
  const nuevo = db
    .prepare('SELECT * FROM miembros WHERE id = ?')
    .get(resultado.lastInsertRowid);
  res.status(201).json(nuevo);
});

app.listen(PORT, () => {
  console.log(`Gimnasio en marcha: http://localhost:${PORT}`);
});
