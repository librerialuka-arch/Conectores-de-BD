const API_URL = '/api/miembros';

const form = document.getElementById('form-miembro');
const tabla = document.getElementById('tabla-miembros');
const contador = document.getElementById('contador');
const mensaje = document.getElementById('mensaje');

function mostrarMensaje(texto, tipo) {
  mensaje.textContent = texto;
  mensaje.className = tipo;
}

function formatearFecha(iso) {
  const [anio, mes, dia] = iso.split('-');
  return `${dia}/${mes}/${anio}`;
}

function crearFila(miembro) {
  const fila = document.createElement('tr');

  const agregarCelda = (texto, clase) => {
    const celda = document.createElement('td');
    celda.textContent = texto;
    if (clase) celda.className = clase;
    fila.appendChild(celda);
    return celda;
  };

  agregarCelda(miembro.id, 'num');
  agregarCelda(miembro.nombre);

  const celdaPlan = agregarCelda('');
  const etiqueta = document.createElement('span');
  etiqueta.textContent = miembro.plan_pago;
  etiqueta.className = `plan plan-${miembro.plan_pago.toLowerCase()}`;
  celdaPlan.appendChild(etiqueta);

  agregarCelda(formatearFecha(miembro.fecha_registro));
  return fila;
}

async function cargarMiembros() {
  try {
    const respuesta = await fetch(API_URL);
    if (!respuesta.ok) throw new Error('Respuesta invalida del servidor');
    const miembros = await respuesta.json();

    contador.textContent = miembros.length;
    tabla.innerHTML = '';

    if (miembros.length === 0) {
      tabla.innerHTML =
        '<tr><td colspan="4" class="vacio">Todavia no hay miembros. Registralos con el formulario.</td></tr>';
      return;
    }
    miembros.forEach((miembro) => tabla.appendChild(crearFila(miembro)));
  } catch (error) {
    mostrarMensaje('No se pudo cargar la lista. Comprueba que el servidor este en marcha.', 'error');
  }
}

form.addEventListener('submit', async (evento) => {
  evento.preventDefault();

  const datos = {
    nombre: form.nombre.value.trim(),
    plan_pago: form.plan_pago.value,
  };

  const boton = form.querySelector('button');
  boton.disabled = true;

  try {
    const respuesta = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos),
    });
    const resultado = await respuesta.json();
    if (!respuesta.ok) throw new Error(resultado.error || 'No se pudo registrar al miembro.');

    mostrarMensaje(`Miembro registrado: ${resultado.nombre}`, 'ok');
    form.reset();
    cargarMiembros();
  } catch (error) {
    const texto = error instanceof TypeError
      ? 'No se pudo conectar con el servidor. Comprueba que siga en marcha.'
      : error.message;
    mostrarMensaje(texto, 'error');
  } finally {
    boton.disabled = false;
  }
});

cargarMiembros();